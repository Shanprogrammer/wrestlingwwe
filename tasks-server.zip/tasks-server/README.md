# Task-Server

## packages

```bash

# create new app
> nest new task-server

# add graphql support
> yarn add @nestjs/graphql @nestjs/apollo graphql apollo-server-express

# add typeorm support
> yarn add @nestjs/typeorm typeorm mysql2

# add passport support
> yarn add @nestjs/passport passport passport-local
> yarn add --dev @types/passport-local


# add passport + JWT
> yarn add @nestjs/jwt passport-jwt
> yarn add --dev  @types/passport-jwt

```

import { UseGuards } from '@nestjs/common';
import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { UserEntity } from './entities/user.entity';
import { GetUser } from './get.user.decorator';
import { JwtAuthGuard } from './jwt.auth.guard';
import { SigninInputType } from './types/signin.input.type';
import { SigninResponseType } from './types/signin.response.type';
import { UserType } from './types/user.type';
import { UserService } from './user.service';

@Resolver(() => UserType)
export class UserResovler {
  constructor(private userService: UserService) {}

  // @Mutation(() => UserType)
  // signup(@Args('input') input: SignupInputType) {
  //   return this.userService.signup(input);
  // }

  @Mutation(() => SigninResponseType)
  signin(@Args('input') input: SigninInputType) {
    return this.userService.signin(input);
  }

  @Query(() => UserType)
  @UseGuards(JwtAuthGuard)
  profile(@GetUser('user') user: UserEntity) {
    return user;
  }
}

export default {
  secret: 'secret',
};

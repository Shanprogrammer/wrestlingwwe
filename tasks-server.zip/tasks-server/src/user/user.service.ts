import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserEntity } from './entities/user.entity';
import { SigninInputType } from './types/signin.input.type';

@Injectable()
export class UserService {
  constructor(private jwtService: JwtService) {}

  // async signup(input: SignupInputType) {
  //   const { name, email, password } = input;

  //   const user = new UserEntity();
  //   user.name = name;
  //   user.email = email;
  //   user.password = password;
  //   await user.save();

  //   return user;
  // }

  async signin(input: SigninInputType) {
    const { title, description } = input;
    const user = await UserEntity.findOneBy({ title, description });
    if (user) {

      // create payload to create token
      const payload = {
        id: user.id,
        name: user.title,
      };

      // create a token
      const token = this.jwtService.sign(payload);

      return { token };
    }
    else{
      const data = new UserEntity();
      data.title = title;
      data.description = description;
      await data.save();
      const user = await UserEntity.findOneBy({ title, description });

      const payload = {
        id: user.id,
        name: user.title,
      };

      // create a token
      const token = this.jwtService.sign(payload);

      return { token };

    }
   
  }

  // async profile(id: number) {
  //   const user = await UserEntity.findOneBy({ id });
  //   if (!user) {
  //     throw new UnauthorizedException('your account does not exist');
  //   }

  //   return user;
  // }
}

import { Field, InputType } from '@nestjs/graphql';

@InputType()
export class TaskInputType {
  @Field()
  question: string;

  @Field()
  description: string;
}

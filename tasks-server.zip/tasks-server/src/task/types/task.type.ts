import { Field, ID, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class TaskType {
  @Field(() => ID)
  id: number;

  @Field()
  question: string;

  @Field()
  description: string;

}

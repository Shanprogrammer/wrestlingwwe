import { UseGuards } from '@nestjs/common';
import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { UserEntity } from 'src/user/entities/user.entity';
import { GetUser } from 'src/user/get.user.decorator';
import { JwtAuthGuard } from 'src/user/jwt.auth.guard';
import { TaskService } from './task.service';
import { TaskInputType } from './types/task.input.type';
import { TaskType } from './types/task.type';

@Resolver(() => TaskType)
@UseGuards(JwtAuthGuard)
export class TaskResolver {
  constructor(private taskService: TaskService) {}

  @Query(() => [TaskType])
  tasks(@GetUser('user') user: UserEntity) {
    return this.taskService.tasks(user.id);
  }

  @Mutation(() => TaskType)
  createTask(
    @GetUser('user') user: UserEntity,
    @Args('input') input: TaskInputType,
  ) {
    return this.taskService.createTask(user, input);
  }

  // @Mutation(() => TaskType)
  // completeTask(@GetUser('user') user: UserEntity, @Args('id') id: number) {
  //   return this.taskService.completeTask(user.id, id);
  // }

  @Mutation(() => String)
  deleteTask(@GetUser('user') user: UserEntity, @Args('id') id: number) {
    this.taskService.deleteTask(user.id, id);
    return 'deleted';
  }
}

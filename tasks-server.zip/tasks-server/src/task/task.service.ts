import { Injectable, NotFoundException } from '@nestjs/common';
import { UserEntity } from 'src/user/entities/user.entity';
import { TaskEntity } from './entities/task.entity';
import { TaskInputType } from './types/task.input.type';

@Injectable()
export class TaskService {
  async tasks(id: number) {
    return await TaskEntity.findBy({ userId: id });
  }

  async createTask(user: UserEntity, input: TaskInputType) {
    const { question, description } = input;
    const task = new TaskEntity();
    task.question = question;
    task.description = description;
    task.user = user;
    await task.save();
    return task;
  }

  // async completeTask(userId: number, id: number) {
  //   const task = await TaskEntity.findOneBy({ userId, id });
  //   if (!task) {
  //     throw new NotFoundException('Task not found');
  //   }

  //   task.isCompleted = true;
  //   await task.save();

  //   return task;
  // }

  async deleteTask(userId: number, id: number) {
    const task = await TaskEntity.findOneBy({ userId, id });
    if (!task) {
      throw new NotFoundException('Task not found');
    }
    await task.remove();
  }
}
